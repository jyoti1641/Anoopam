// import 'package:flutter/material.dart';
// import 'screens/home_screen.dart';
// import 'providers/audio_providers.dart';

// class AudioScreen extends StatelessWidget {
//   const AudioScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return AudioProviders(
//       child: const HomeScreen(),
//     );
//   }
// }
